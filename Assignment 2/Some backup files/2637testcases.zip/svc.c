#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "svc.h"
#include "accessory.h"

#define DEBUG printf("this is working\n");

#define HEX_DIDGETS 7


//--------------------------------------------------------------------------------FUNCTION DECLARATIONS-----------------------------------------------------------------------//

void *svc_init(void);

void cleanup(void *helper);

void free_branch_list(linked_list_branch* branch_list);

void free_branch(node_branch* temp_branch);

void free_commit_list(linked_list_commit *commit_list);

void free_commit(node_commit *temp_commit);

void free_file_list(linked_list_file* file_list);

void free_file(node_file* temp_file);

int calculate_hash_file(char *file_path);

int hash_file(void *helper, char *file_path);

char *svc_commit(void *helper, char *message);

void create_commit(branch* branch, commit** temp_com, char* message, char* commit_id);

void manage_branch(branch** head_branch_ptr);

void copy_file(file* src, file** dest);

char* get_commit_id(char* message,branch* branch);

int find_num_digits(int hex_val);

void update_files(linked_list_file** file_list);

void *get_commit(void *helper, char *commit_id);

char **get_prev_commits(void *helper, void *commit, int *n_prev);

void print_commit(void *helper, char *commit_id);

int check_if_changed(branch* branch);

int name_valid(char* branch_name);

int name_occupied(void* helper, char* branch_name);

void copy_file_list(linked_list_file* src, linked_list_file** dest);

int svc_branch(void *helper, char *branch_name);

int svc_checkout(void *helper, char *branch_name);

char **list_branches(void *helper, int *n_branches);

int svc_add(void *helper, char *file_name);

int svc_rm(void *helper, char *file_name);

//--------------------------------------------------------------------------------FUNCTION TO EDIT AND CREATE-----------------------------------------------------------------//
/**
DESCRIPTION:
        Reset the current branch to the commit with the id given and disregard any uncommitted changes.

RETURN VALUE: -1
        commit_id is NULL
RETURN VALUE: -2
        There is no corresponding commit with the id provided.
RETURN VALUE:
**/

int svc_reset(void *helper, char *commit_id){
    // TODO: Implement
    return 0;
}

/**
DESCRIPTION:
        this function will be called to Merge the currently active branch with the branch with the name provided.
        First it needs to check if the two branches are valid to merge.

Validity to merge is dependant on:
        - branch_name provided is NOT NULL
        - branch with corresponding branch_name that is the same as the branch_name provided
        - branch_name provided is not the currently active branch
        - current branch has no uncommitted changes.
**/
char *svc_merge(void *helper, char *branch_name, struct resolution *resolutions, int n_resolutions){

  //checking for validity of branch provided
  my_helper* manager = (my_helper*) helper;
  if(branch_name == NULL){
    printf("Invalid branch name\n");
    return NULL;
  }
  else if(strcmp(manager -> head -> branch_name, branch_name) == 0){
    printf("Cannot merge a branch with itself\n");
    return NULL;
  }
  node_branch* branch_cursor = manager -> branches -> first;
  while( branch_cursor != NULL){
    if(strcmp(branch_cursor -> current_branch -> branch_name, branch_name) == 0){
      break;
    }
    branch_cursor = branch_cursor -> next;
  }
  if(branch_cursor == NULL){
    printf("Branch not found\n");
    return NULL;
  }
  update_files(&branch_cursor -> current_branch -> managed_files);
  node_file* file_cursor = branch_cursor -> current_branch -> managed_files -> first;
  while(file_cursor != NULL){
    if(file_cursor -> current_file -> state != 0){
      printf("Changes must be committed\n");
      return NULL;
    }
    file_cursor = file_cursor-> next;
  }

  node_file* head_branch_file_cursor = manager -> head -> managed_files -> first;

  //checking if there is any clasing files;
  while(head_branch_file_cursor != NULL){
    node_file* selected_branch_file_cursor = branch_cursor -> managed_files -> first;
    while(selected_branch_file_cursor != NULL){
      if(strcmp( selected_branch_file_cursor -> current_file -> file_name, head_branch_file_cursor -> current_file -> file_name) == 0){
        if(resolutions == NULL){
          resolutions = (struct resolution*) malloc(sizeof(struct resolution));
        }
      }
    }
  }

  return NULL;
}

//-----------------------------------------------------------------------------------CODES I IMPLEMENTED --------------------------------------------------------------------//

/**
DESCRIPTION:
        This is to create and return the pointer to my my_helper variable.
RETURN VALUE: Pointer to dynamically allocated my_helper.
**/
void *svc_init(void){
  my_helper* manager = (my_helper*) malloc(sizeof(my_helper));

  //initialising the branch
  manager -> branches = (linked_list_branch*) malloc(sizeof(linked_list_branch));
  manager -> branches -> length = 1;
  manager -> branches -> first = (node_branch*) malloc(sizeof(node_branch));
  manager -> branches -> first -> next = NULL;
  manager -> branches -> first -> previous = NULL;
  manager -> branches -> first -> current_branch = (branch*) malloc(sizeof(branch));
  manager -> branches -> first -> current_branch -> branch_name = (char*) malloc(strlen("master")+1);
  strcpy(manager -> branches -> first -> current_branch -> branch_name,"master");
  manager -> branches -> first -> current_branch -> managed_files = (linked_list_file*) malloc(sizeof(linked_list_file));
  manager -> branches -> first -> current_branch -> managed_files -> first = NULL;
  manager -> branches -> first -> current_branch -> managed_files -> length = 0;


  //initialising the commits
  manager -> commits = (linked_list_commit*) malloc(sizeof(linked_list_commit));
  manager -> commits -> first = NULL;
  manager -> commits -> length = 0;

  //initialising head
  manager -> head = manager -> branches -> first -> current_branch;
  return manager;
}

/**
DESCRIPTION:
        - Called once after other functions have been called ensuring all dynamically allocated memory has been freed when this function returns;
        - Should free up all the dynamically allocated memory
**/
void cleanup(void *helper){

  my_helper* manager = (my_helper*) helper;

  //free branches
  free_branch_list(manager -> branches);

  //free commits
  free_commit_list(manager -> commits);

  //free the helper itself.
  free(manager);
}

/**
DESCRIPTION:
        Free up the branch linked list by:
            1. Traverse through the linked_list_branch *branch_list and free up all the branch nodes within it.
            2. free the linked_list_branch *branch_list itself.
**/
void free_branch_list(linked_list_branch* branch_list){

  if(branch_list != NULL){

    //Traverse through individual branch nodes in branch linked list and pass it over to free_branch function.
    node_branch* branch_cursor = branch_list -> first;
    node_branch* node_to_free = NULL;
    while(branch_cursor != NULL){
      free_branch(branch_cursor);
      node_to_free = branch_cursor;
      branch_cursor = branch_cursor -> next;
      free(node_to_free);
    }

    //Free the branch_list itself.
    free(branch_list);
  }
}

/**
DESCRIPTION:
      Free the branch node and its pointed branch struct in order of:
            1. Branch's branch_name;
            2. Pass over the branch's managed_files to free_file_list function to free file linked list;
            3. Branch struct itself
            4. Branch Node;
**/
void free_branch(node_branch* temp_branch){
  free(temp_branch -> current_branch -> branch_name);
  free_file_list(temp_branch -> current_branch -> managed_files);
  free(temp_branch -> current_branch);
}

/**
DESCRIPTION:
        Free up the commit linked list by:
            1. Traverse through the linked_list_commit *commit_list and free up all the commit nodes within it.
            2. free the linked_list_commit *commit_list itself.
**/
void free_commit_list(linked_list_commit *commit_list){
  if(commit_list != NULL){

    //Free the node_commit as going along the linked list
    node_commit *commit_cursor = commit_list -> first;
    node_commit *node_to_free = NULL;
    while(commit_cursor != NULL){
      free_commit(commit_cursor);
      node_to_free = commit_cursor;
      commit_cursor = commit_cursor -> next;
      free(node_to_free);
    }

    //free the linked list
    free(commit_list);
  }
}

/**
DESCRIPTION:
        Free the commit node and it's pointed commit struct in order of:
            1. Commit's commit_id;
            2. Commit's commit_message;
            3. Commit's branch_name;
            4. Pass over commit's managed_files to free_file function for the file linked list to be freed;
            5. Commit struct;
            6. Commit node;
**/
void free_commit(node_commit *temp_commit){
  free(temp_commit -> current_commit -> commit_id);
  free(temp_commit -> current_commit -> commit_message);
  free(temp_commit -> current_commit -> branch_name);
  free_file_list(temp_commit -> current_commit -> managed_files);
  free(temp_commit -> current_commit);
}

/**
DESCRIPTION:
        Free up the linked list of files by:
          1. Traversing through them all and calling free_file function to free individual file nodes
          2. Free the linked list itself.
**/
void free_file_list(linked_list_file* file_list){
  if(file_list != NULL){

    //Traverse through individual file node and passing it over to free_file function.
    node_file* temp_file = file_list -> first;

    node_file* node_to_free= NULL;
    while(temp_file != NULL){
      free_file(temp_file);
      node_to_free = temp_file;
      temp_file = temp_file -> next;
      free(node_to_free);
    }

    //Free file linked list itself.
    free(file_list);
  }
}

/**
DESCRIPTION:
        Free the file node and it's pointed file struct in order of:
            1. File struct's file_name
            2. File struct itself is freed after
            3. File node is freed last
**/
void free_file(node_file* temp_file){
  if(temp_file -> current_file != NULL){
    free(temp_file -> current_file -> file_name);
  }
  free(temp_file -> current_file);
}

/**
DESCRIPTION:
        Calculate hash value of the path provided and return the value.
        Checkings are not done here as it is done prior to calling this.

RETURN VALUE: hash value of file.

**/
int calculate_hash_file(char *file_path){
  int c;
  int hash_value = 0;
  int file_name_sum = 0;
  int file_content_sum = 0;
  FILE* fptr = fopen(file_path, "r");

  //Update value of hash_value according to each characters in file_path;
  for(int j = 0; j < strlen(file_path); j++){
      file_name_sum = (file_name_sum + file_path[j]);
  }

  //Update value of hash_value according to each characters in the file;
  while((c=fgetc(fptr))!=EOF){
    file_content_sum = (file_content_sum + c);
  }

  hash_value = file_name_sum %1000;
  hash_value = (hash_value + file_content_sum) % 2000000000;

  fclose(fptr);
  return hash_value;
}

/**
DESCRIPTION:
        -Given the path to a file, comput and return the hash value.

Successive Use Case Steps:
        1. check if file_path is NULL or if it exists.
        2. Calcualte initial hash value with the file_path given.
        3. Calculate following hash value according to each byte value in the file's content.
        4. return the value.

RETURN VALUE: -1
        - file_path provided is NULL
RETURN VALUE: -2
        - file_path does not address any file.
        - File does not exist.
RETURN VALUE: hash value of the file
        - file_path is valid and value is successfully calculated.

**/
int hash_file(void *helper, char *file_path){

  //Check if file_path is NULL;
  if(file_path == NULL) {
    return -1;
  }

  //Open file;
  FILE* fptr = fopen(file_path, "r");

  //Check if file does exist;
  if(fptr == NULL) {
    return -2;
  }

  //Close the file;
  fclose(fptr);

  int hash_value = calculate_hash_file(file_path);
  //Return the hash_value calculated;
  return hash_value;
}

/**
DESCRIPTION:
        To go through each file in file linked list given and to check if the hash_value of the file has changed or not.
        If it did and if the file -> state was 0, change it to 1.
        Assign the new file hash value to file -> hashvalue regardless of if file -> state was 0 or 1 if the internal content has changed;

        If file was not found in this phase, it means that the specified file was deleted by the user and the file's state needs to change to 3
**/
void update_files(linked_list_file** file_list){
  node_file* file_cursor = (*file_list) -> first;
  while(file_cursor != NULL) {

    FILE* fptr = fopen(file_cursor -> current_file -> file_name, "r");
    //if file does not exist anymore then change it's value as 3 and move on.
    if(fptr == NULL){
      file_cursor -> current_file -> state = 3;
    }
    //if file does exist then get it's hash value again and see if it is different, if so it has changed,
    //update it.
    else{
      fclose(fptr);
      int hashvalue = calculate_hash_file(file_cursor -> current_file -> file_name);
      if(file_cursor -> current_file -> file_hash != hashvalue){
        if(file_cursor -> current_file -> state == 0){
          file_cursor -> current_file -> state = 1;
        }
        file_cursor -> current_file -> file_hash = hashvalue;
      }
    }
    file_cursor = file_cursor -> next;
  }
}

/**
DESCRIPTION:
        Calculate how many didgets there are in the value and return the number of didgets.
RETURN VALUE: number of didgets calculated
**/
int find_num_digits(int hex_val){
  int num_didgets = 0;
  while(hex_val > 0){
    num_didgets++;
    hex_val/=10;
  }
  return num_didgets;
}

int change(char* text_1, char* text_2){
  int len = 0;
  if(strlen(text_1) > strlen(text_2)){
    len = strlen(text_2);
  }
  else{
    len = strlen(text_1);
  }
  for(int i = 0; i < len; i++){
    int text_1_ascii = text_1[i];
    int text_2_ascii = text_2[i];
    // printf("%c %d vs %c %d\n\n",text_1_ascii,text_1_ascii,text_2_ascii,text_2_ascii);
    if(65<=text_1_ascii && text_1_ascii <= 90){
      text_1_ascii += 32;
    }
    if(65<=text_2_ascii && text_2_ascii <= 90){
      text_2_ascii += 32;
    }
    if(text_1_ascii > text_2_ascii){
      return 1;
    }
    else if(text_1_ascii < text_2_ascii){
      return 0;
    }
  }
  return 0;
}

void swap_text(node_text** base_cursor, node_text** to_swap ){
  node_text* temporary = (node_text*) malloc(sizeof(node_text));
  temporary -> current_text = (char*) malloc(strlen((*base_cursor) -> current_text) + 1);
  strcpy(temporary -> current_text, (*base_cursor) -> current_text);
  temporary -> state = (*base_cursor) -> state;

  (*base_cursor) -> current_text = (char*) realloc((*base_cursor) -> current_text, strlen((*to_swap) -> current_text) + 1);
  strcpy((*base_cursor) -> current_text, (*to_swap) -> current_text);
  (*base_cursor) -> state = (*to_swap) -> state;

  (*to_swap) -> current_text = (char*) realloc((*to_swap) -> current_text, strlen(temporary -> current_text) + 1);
  strcpy((*to_swap) -> current_text, temporary -> current_text);
  (*to_swap) -> state = temporary -> state;

  free(temporary -> current_text);
  free(temporary);
}

void sort_alphabetical(linked_list_text** destination){
  node_text* base_cursor = (*destination) -> first;
  node_text* text_cursor = NULL;
  while(base_cursor != NULL){
    int swap = 0;
    node_text* to_swap = base_cursor;
    text_cursor = base_cursor;
    while(text_cursor != NULL){
      if(change(to_swap -> current_text, text_cursor -> current_text)){
        swap = 1;
        to_swap =  text_cursor;
      }
      text_cursor = text_cursor-> next;
    }

    if(swap == 1){
      swap_text(&base_cursor, &to_swap);
    }
    base_cursor = base_cursor->next;
  }
}

void free_text_linked_list(linked_list_text* list){
  node_text* text_cursor = list -> first;
  node_text* temporary = NULL;
  while(text_cursor != NULL){
    free( text_cursor -> current_text);
    temporary = text_cursor;
    text_cursor = text_cursor -> next;
    free(temporary);
  }
  free(list);
}

/**
DESCRIPTION:
        Calculate and return the Hexadecimal ID for the commit.

Successive Use Case:
        1. Calculate initial hexavalue by looking into each characters of the message.
        2. For each changed files:
            1. First add a value depending on how the file is changed:
                - If it is changed(file -> state = 1): add  9573681 to hexavalue
                - If it is added(file -> state = 2): add  376591 to hexavalue
                - If it is removed(file -> state = 3): add 85973 to hexavalue
            2. Update hexavalue depending on each characters of the file name which is the path of the file.
        3. Calculate the number of didgets in the hexavalue.
        4. Allocate char* pointer with space equavalant to the number of didgets in hexavalue.
        5. Convert and place converted hexadecimal representation of hex_val onto hexa_representation and return hexa_representation;

**/
char* get_commit_id(char* message, branch* branch){
  int hex_val = 0;

  //Calculating initial value of hex_val by looking into individual characters of the message.
  for(int i = 0; i < strlen(message); i++){
    hex_val = (hex_val + message[i])%1000;
  }

  node_file* file_cursor = branch -> managed_files -> first;
  linked_list_text* text_list = (linked_list_text*) malloc(sizeof(linked_list_text));
  text_list -> first = NULL;

  node_text* text_cursor = text_list -> first;
  text_list -> length = 0;
  while(file_cursor != NULL){
    if(file_cursor -> current_file -> state != 0){
      if(text_cursor == NULL){
        text_list -> first = (node_text*) malloc(sizeof(node_text));
        text_list -> first -> next = NULL;
        text_list -> first -> previous = NULL;
        text_cursor = text_list -> first;
      }
      else{
        text_cursor -> next = (node_text*) malloc(sizeof(node_text));
        text_cursor -> next -> previous = text_cursor;
        text_cursor -> next -> next = NULL;
        text_cursor = text_cursor-> next;
      }
      text_cursor -> current_text = (char*) malloc(strlen(file_cursor -> current_file ->file_name) +1);
      strcpy(text_cursor -> current_text,file_cursor -> current_file ->file_name);
      text_cursor -> state = file_cursor -> current_file -> state;
      text_list -> length ++;
    }
    file_cursor = file_cursor-> next;
  }

  sort_alphabetical(&text_list);
  text_cursor = text_list -> first;
  while(text_cursor != NULL){
    text_cursor = text_cursor -> next;
  }

  text_cursor = text_list -> first;


  //traversing through given branch's managed_files linked list to see what changes have been made.
  while(text_cursor != NULL) {

    //Add value onto hex_val depending on what changes have been made onto each file.
    if(text_cursor-> state == 1){
      hex_val += 9573681;
    }
    else if(text_cursor -> state == 2){
      hex_val += 376591;
    }
    else if(text_cursor -> state == 3){
      hex_val += 85973;
    }
    //Update hex_val depending on the file name of each changed files.

    for( int i = 0 ; i < strlen( text_cursor -> current_text); i++ ) {
      hex_val = (hex_val * (((int) text_cursor -> current_text[i]) %37)) %15485863 +1;
    }

    text_cursor = text_cursor -> next;

  }
  free_text_linked_list(text_list);

  //Create space and put converted hexadecimal values onto it.
  char *hexa_representation = (char*) malloc(HEX_DIDGETS);
  sprintf(hexa_representation, "%x", hex_val);
  hexa_representation[HEX_DIDGETS-1] = '\0';
  if(strlen(hexa_representation) != HEX_DIDGETS){
    char* temp = (char*) malloc(HEX_DIDGETS);
    for(int i = 0; i < HEX_DIDGETS-strlen(hexa_representation)-1;i++){
      temp[i] = '0';
    }
    for(int i = 0; i < strlen(hexa_representation); i++){
      temp[HEX_DIDGETS - strlen(hexa_representation) -1 + i] = hexa_representation[i];
    }
    temp[HEX_DIDGETS -1] = '\0';
    free(hexa_representation);
    return temp;
  }
  return hexa_representation;
}

/**
DESCRIPTION:
        Given the source file struct, deep copy it's entities onto the file struct destination provided.

Successive Use Case:
        1. Allocate space for destination file struct.
        2. Allocate space for file name
        3. Copy source file struct's name onto destination struct's names
        4. Copy the course file' hash value
        5. Copy the state of source file.
**/
void copy_file(file* src, file** dest){
  (*dest) = (file*) malloc(sizeof(file));
  (*dest) -> file_name = (char*) malloc(strlen(src -> file_name) + 1);
  strcpy((*dest) -> file_name, src -> file_name);
  (*dest) -> file_hash = src -> file_hash;
  (*dest) -> state = src -> state;
}

/**
DESCRIPTION:
        Update managed file's file -> state and delete any deleted files from tracked files or change any state from either 1 or 2 to 0.
**/
void manage_branch(branch** head_branch_ptr){
  branch* head_branch = *head_branch_ptr;
  node_file* file_cursor = head_branch -> managed_files -> first;
  node_file* node_to_free = NULL;
  while(file_cursor != NULL){

    //If the state of file is 3, Remove the file from the linked list.
    if(file_cursor -> current_file -> state == 3){

      //when its the only one in the file linked list
      if(file_cursor -> previous == NULL && file_cursor -> next == NULL){
        free(head_branch -> managed_files -> first -> current_file -> file_name);
        free(head_branch -> managed_files -> first -> current_file);
        free(head_branch -> managed_files -> first);
        head_branch -> managed_files -> first = NULL;
        head_branch -> managed_files -> length -=1;
        return;
      }

      //if this file node is he first;
      else if(file_cursor -> previous == NULL){
        file_cursor -> next -> previous = NULL;
        head_branch -> managed_files -> first = file_cursor -> next;
      }

      //if this file node is the last;
      else if(file_cursor -> next == NULL){
        file_cursor -> previous -> next = NULL;
      }

      //if it is in the middle
      else{
        file_cursor -> next -> previous = file_cursor -> previous;
        file_cursor -> previous -> next = file_cursor -> next;
      }
      head_branch -> managed_files -> length -=1;
      node_to_free = file_cursor;
    }

    //Else file_cursor -> current_file -> state is either 0,1,2 which should all be converted to 0.
    else{
      file_cursor -> current_file -> state = 0;
    }
    file_cursor = file_cursor -> next;
    if(node_to_free != NULL){
      free(node_to_free -> current_file -> file_name);
      free(node_to_free -> current_file);
      free(node_to_free);
      node_to_free = NULL;
    }
  }
}

/**
DESCRIPTION:
        Create commit struct and place all the values of branch onto it, save message and commit_id into it as well.

Successive Use Case:
        1. Allocate the commit struct that has been passed in.
        2. Allocate space and copy the commit_id, message and branch name onto it.
        3. Deep copy all the files managed in the branch.
            1. Allocate space with type linked_list_file in commit's managed_files.
            2. Traverse through the linked list in branch and Deep Copy all of the file node in branch's file linked list.
                1. Allocate node_file pointer and pass the address of node_file pointer's current_file and currently pointer file node's file
                   to copy_file function to deep copy file struct.
                2. Set allocated file node pointer -> next value to be NULL
                3. Check if there is any last updated file node:
                      - if there is not, it means it is the first in the linked list so you should assign the linked list's first value to be the allocated file node.
                      - if there is, link the two nodes together.
                4. Update the number of entity in linked list on created commit's managed_files linked list.
                5. update last_updated and file_cursor.
**/
void create_commit(branch* branch, commit** temp_com, char* message, char* commit_id){

  //Allocating the commit struct that has been passed in.
  (*temp_com) = (commit*) malloc(sizeof(commit));

  /**Allocating and copying the values of:
          - commit_id
          - commit_message
          - branch_name;
  **/
  (*temp_com) -> commit_id = (char*) malloc(strlen(commit_id) +1);
  strcpy((*temp_com) -> commit_id,commit_id);
  free(commit_id);

  (*temp_com) -> commit_message = (char*) malloc(sizeof(char)* (strlen(message)+1));
  strcpy((*temp_com) -> commit_message, message);
  (*temp_com) -> branch_name = (char*) malloc(sizeof(char) * (strlen(branch -> branch_name)+1));
  strcpy((*temp_com) -> branch_name, branch -> branch_name);

  //Deep copy of all of files managed in that branch;

  //Allocating file linked list space to the Allocated commit's managed_files.
  (*temp_com) -> managed_files = (linked_list_file*) malloc(sizeof(linked_list_file));
  (*temp_com) -> managed_files -> first = NULL;
  (*temp_com) -> managed_files -> length = 0;

  //Traversing through the given branch's managed file linked list and deep copying all the file node.

  //Storing the value of the last updated file node.
  node_file* commit_file_cursor = (*temp_com) -> managed_files -> first;
  node_file* file_cursor = branch -> managed_files -> first;

  while(file_cursor != NULL){

    //Allocate space for file Copy
    if(commit_file_cursor == NULL){
      (*temp_com) -> managed_files -> first = (node_file*) malloc(sizeof(node_file));
      (*temp_com) -> managed_files -> first -> previous = NULL;
      (*temp_com) -> managed_files -> first -> current_file = NULL;
      (*temp_com) -> managed_files -> first -> next = NULL;
      commit_file_cursor = (*temp_com) -> managed_files -> first;

    }
    else{
      commit_file_cursor -> next = (node_file*) malloc(sizeof(node_file));
      commit_file_cursor -> next -> next = NULL;
      commit_file_cursor -> next -> current_file = NULL;
      commit_file_cursor -> next -> previous = commit_file_cursor;
      commit_file_cursor = commit_file_cursor -> next;
    }

    //deep copy files by calling copy_file
    copy_file(file_cursor -> current_file, &commit_file_cursor -> current_file);
    //Incrementing the length of linked listl
    (*temp_com) -> managed_files -> length ++;
    file_cursor = file_cursor -> next;
  }
}

/**
DESCRIPTION:
        Create a commit with message given, and all the changes to the files being tracked on the currently active head branch.
        After which, this function will return the commit_id of the commit that just been created if it was successfully processed or
        NULL if either:
            - message is NULL
            - There is no changes from the last.

Successive Use Case:
        1. Update the hash value of the file within each managed files of head branch and change file state accordingly.
        2. Check if the message given is NULL or if there has been changes since last commit.
              -Checking for changes is done by looking at the managed file's state value to see if it is NOT 0.
        3. Calculate the commit_id that should be assigned onto the commit based on the currently active head branch.
        4. Check if the commit linked list in my_helper is NULL, if so, we need to assign the commit in the commit linked list -> first.
           Else
           Traverse through commit linked list to find the last commit and allocate a space for commit node in last commit -> next values
        5. Call create_commit function passing in the my_helper -> head branch, recently allocated commit, message passed and commit_id calculated to correctly assign.
        6. Update the managed_files in branch to:
              - Delete and Free any deleted files from the managed_files linked list.
              - Change the state value of each files to 0 else.
        7. Return commit_id of currently created commit.

RETURN VALUE: NULL
        - message given is NULL
        - No changes since last commit

RETURN VALUE: commit_id of currently created commit
        - No issue was flagged and the commit was done successfully.

**/
char *svc_commit(void *helper, char *message){
  my_helper* help = (my_helper*) helper;

  //Update the file -> file_hash and file -> state value if the file has been changed from initial submission.
  update_files(&help -> head -> managed_files);

  //Check if message is NULL;
  if(message == NULL){
    return NULL;
  }

  //Variable representing boolean flag to whether any files has changed or not;
  size_t changed = 0;

  //Traverse through helper -> head's managed_files linked list to see if any is changed by looking into the state.
  node_file* file_cursor = help -> head -> managed_files -> first;
  while(file_cursor != NULL){
    //If temp_file -> current_file -> state is of value other than 0 (1,2,3) it means they have been changed, added, removed
    if(file_cursor -> current_file -> state != 0){
      changed = 1;
      break;
    }
    file_cursor = file_cursor-> next;
  }

  //If files no files has changed, return NULL;
  if(changed == 0){
    return NULL;
  }

  //Calculate appropriate commit_id by passing the message and the current active head branch to get_commit_id function.
  //commit_id is malloc'ed in get_commit_id function.
  char* commit_id = get_commit_id(message ,help -> head);

  //Traverse through the commit linked list to see get the last commit node.
  //If linked list has not been initialised, the commit_cursor will hold the address of the first commit position in the linked list.
  node_commit* commit_cursor = NULL;

  //If commit linked list has not been initialised, allocate and set commit_cursor as the first.
  //else
  //Traverse through and let commit_cursor be pointing at the last commit's next value and previous_commit_node be the last commit.
  if(help -> commits -> first == NULL){
    help -> commits -> first = (node_commit*) malloc(sizeof(node_commit));
    help -> commits -> length = 0;
    commit_cursor = help -> commits -> first;
    commit_cursor -> next = NULL;
    commit_cursor -> previous = NULL;
    commit_cursor -> current_commit = NULL;
  }
  else{
    commit_cursor = help -> commits -> first;
    while(commit_cursor -> next != NULL){
      commit_cursor = commit_cursor -> next;
    }
    commit_cursor -> next = (node_commit*) malloc(sizeof(node_commit));
    commit_cursor -> next -> next = NULL;
    commit_cursor -> next -> previous = commit_cursor;
    commit_cursor -> next -> current_commit = NULL;
    commit_cursor = commit_cursor -> next;
  }

  /**Create commit by passing:
          - Currently active head branch;
          - address of commit struct to store the created commit in.
          - message provided;
          - commit_id calculated;
  **/
  create_commit(help -> head, &commit_cursor -> current_commit, message, commit_id);

  //Update currently active head branch's managed files by passing the address of head branch to manage_branch function;
  manage_branch(&help -> head);

  help -> commits -> length ++;

  return commit_cursor -> current_commit ->  commit_id;
}

/**
DESCRIPTION:
        Given commit_id, search and return a pointer to the commit with corresponding commit_id.
        If there is no commit with corresponding commit_id, or commit_id is NULL, return NULL

RETURN VALUE: NULL
        - commit_id is NULL
        - commit_id does not correspond to any commits in the commit list.

RETURN VALUE: address of commit
        - commit_id search was successful.
**/
void *get_commit(void *helper, char *commit_id){
  my_helper* manager = (my_helper*) helper;

  //If commit_id provided is NULL;
  if( commit_id == NULL ) {
    return NULL;
  }

  //If there is no commits in my_helper,
  if( manager -> commits == NULL ) {
    return NULL;
  }

  //Traverse through the linked list untill you find the commit with correspond commit_id and return that value;
  node_commit* commit_cursor =  manager -> commits -> first;
  while(commit_cursor != NULL){
    if(strcmp(commit_cursor -> current_commit-> commit_id,commit_id)==0){
      return commit_cursor -> current_commit;
    }
    commit_cursor = commit_cursor -> next;
  }

  //At this point, no commit corresponds to the commit_id given, thus it returns NULL;
  return NULL;
}

/**
DESCRIPTION:
        Given a pointer to a commit, return a DYNAMICALLY ALLOCATED ARRAY, each containing the commit_id of it's previous commits.
        The number of commits should be stored in n_prev int pointer passed as parameter;

Successive Use Case:
        1. Check if the parameter is valid by checking either
                - n_prev is NOT NULL
                - commit is NOT NULL
                - commit is NOT the first of the linked list
        2. Traverse though the linked list untill you reach the commit corresponding to the commit provided.
        3. Allocate a list which can hold all the commit_ids of the parent commit
        4. At this point the Cursor should be pointing at the commit what has been passed.
           So decrement the position by one and assign the list in a decreasing order from the most left element
           This is because we are traversing backwards, meaning the order is reversed.

RETURN VALUE: NULL
        - If n_prev is NULL
RETURN VALUE: NULL/ n_prev = 0
        - If commit passed is NULL.
        - Commit is first commit in linked list.
RETURN VALUE: dynamically allocated array holding commit_id of the past, n_prev is the number of commit_id in the array
        - If the process was done correctly.
**/
char **get_prev_commits(void *helper, void *commit_pointer, int *n_prev){
  my_helper* manager = (my_helper*) helper;
  commit* ref_commit = (commit*) commit_pointer;
  // If n_prev is NULL;
  if(n_prev == NULL){
    return NULL;
  }

  //If commit provided is NULL OR
  //commit provided is the first commit of the linked list.
  else if(commit_pointer == NULL || strcmp(manager -> commits -> first -> current_commit -> commit_id,ref_commit -> commit_id) == 0){
    *n_prev = 0;
    return NULL;
  }

  //Traverse though the commits linked list and check if you find the correct corresponding commit
  node_commit* commit_cursor =  manager -> commits -> first;
  int num_parent_commit = 0;
  while(commit_cursor != NULL) {
    if(strcmp(commit_cursor -> current_commit -> commit_id,ref_commit -> commit_id) == 0){
      break;
    }
    num_parent_commit++;
    commit_cursor = commit_cursor-> next;
  }

  //Decrement the position of commit_cursor by 1 position back.
  commit_cursor = commit_cursor -> previous;

  //Allocate list accordingly
  char** list_commit_id = (char**) malloc(sizeof(char*) * num_parent_commit);
  *n_prev = num_parent_commit;

  //this is put in reverse because the order of traverse is done in reverse.
  for( int i = num_parent_commit-1; i >= 0; i --){
    list_commit_id[i] = commit_cursor -> current_commit -> commit_id;
    commit_cursor = commit_cursor -> previous;
  }
  return list_commit_id;
}

int get_n_didgits(int num){
  int i = 0;
  while(num > 0){
    num = num / 10;
    i++;
  }
  return i;
}

/**
DESCRIPTION:
        Given a commit_id, print the details of the commit as specified in the requirements.

PRINT VALUE: "Invalid commit id"
        - There is no corresponding commit with current commit_id
        - commit_id is NULL
**/
void print_commit(void *helper, char *commit_id){
    commit* commit_to_print = (commit*) get_commit(helper, commit_id);
    if(commit_to_print == NULL){
      printf("Invalid commit id\n");
      return;
    }
    else{
      printf("%s [%s]: %s\n", commit_to_print -> commit_id, commit_to_print -> branch_name, commit_to_print -> commit_message);

      //Traverse through and find files with file -> state == 2 added files
      node_file* file_cursor = commit_to_print -> managed_files -> first;
      while(file_cursor != NULL){
        if(file_cursor -> current_file -> state == 2){
          printf("    + %s\n", file_cursor -> current_file -> file_name);
        }
        file_cursor = file_cursor -> next;
      }

      //Traverse though and find files with file -> state == 3 for removed files
      file_cursor = commit_to_print -> managed_files -> first;
      while(file_cursor != NULL){
        if(file_cursor -> current_file -> state == 3){
          printf("    - %s\n", file_cursor -> current_file -> file_name);
        }
        file_cursor = file_cursor -> next;
      }

      //Traverse through and find files with file -> state == 1 for changed files
      file_cursor = commit_to_print -> managed_files -> first;
      while(file_cursor != NULL){
        if(file_cursor -> current_file -> state == 1){
          printf("    / %s\n", file_cursor -> current_file -> file_name);
        }
        file_cursor = file_cursor -> next;
      }

      printf("\n");

      file_cursor = commit_to_print -> managed_files -> first;
      int num_tracked = 0;

      while(file_cursor != NULL){
        if(file_cursor -> current_file -> state != 3){
          num_tracked ++;
        }
        file_cursor = file_cursor -> next;
      }
      printf("    Tracked files (%d):\n",num_tracked);
      file_cursor = commit_to_print -> managed_files -> first;

      //Traverse Through the linked list and print the names of all the list that has file-> state that is NOT 3(removed)
      while(file_cursor != NULL){
        if(file_cursor -> current_file -> state != 3){
          printf("    ");
          int n_didgits = get_n_didgits(file_cursor ->current_file -> file_hash);
          printf("[");
          for(int i = 0; i < (10 - n_didgits);i++){
            printf(" ");
          }
          printf("%d]", file_cursor ->current_file -> file_hash);
          printf(" %s\n",file_cursor -> current_file -> file_name );
        }
        file_cursor = file_cursor -> next;
      }
    }
}

/**
DESCRIPTION:
        Updates and checks if there is any file in the branch's managed_files linked list and
        returns an integer value of whether there is a changed file or not

RETURN VALUE: 1
        - If there is a file with file-> state that is NOT 0 (meaning that the file has either changed, added or removed)

RETURN VALUE: 0
        - If there is NO file that has been added,changed or removed
**/
int check_if_changed(branch* branch){
  update_files(&branch -> managed_files);
  node_file* file_cursor = branch -> managed_files -> first;
  while(file_cursor != NULL){
    if(file_cursor-> current_file -> state != 0){
      return 1;
    }
    file_cursor = file_cursor -> next;
  }
  return 0;
}

/**
DESCRIPTION:
        Checks whether the branch name provided is a valid name or not.

DEFINITION: VALID BRANCH NAME
        If the branch name consists of characters of:
                - a-z
                - A-Z
                - 0-9
                - '-'
                - '_'
                - "/"

RETURN VALUE: 1
        If the branch name is NOT VALID
RETURN VALUE: 0
        If the branch name is VALID
**/
int name_valid(char* branch_name){
  for(int i = 0; i < strlen(branch_name); i++){
    int val = (int) branch_name[i];
    if((65 <= val && val <= 90) || (97<= val && val <= 122) || (48<=val && val <=57) ||val == 95 || val == 45 || val == 47){
    }
    else{
      return 1;
    }
  }
  return 0;
}

/**
DESCRIPTION:
        Checks Whether the branch name provided already exists within the my_helper branches list.

RETURN VALUE: 1
        If the branch name provided is OCCUPIED.
RETURN VALUE: 0
        If the branch name provided is NOT OCCUPIED.
**/
int name_occupied(void* helper, char* branch_name){

  //Traverse through helper -> branches linked list and see if there is any branch with the same name as the branch name provided.
  node_branch* branch_cursor = ((my_helper*) helper) -> branches -> first;
  while(branch_cursor != NULL){
    if(strcmp(branch_cursor -> current_branch -> branch_name,branch_name)==0){
      return 1;
    }
    branch_cursor = branch_cursor-> next;
  }
  return 0;
}

/**
DESCRIPTION:
        Do a deep copy of the source linked list with the destination linked list by:
                1. Allocating space for linked list in destination provided.
                2. Traverse though the source's file linked list and call copy_file to transfer information over to the destination linked list
**/
void copy_file_list(linked_list_file* src, linked_list_file** dest){

  //Initially dest is not allocated so it needs to be allocated.
  *dest = (linked_list_file*) malloc(sizeof(linked_list_file));
  linked_list_file* destination = *dest;

  //First node also needs to be allocated
  destination -> first = (node_file*) malloc(sizeof(node_file));
  destination -> first -> next = NULL;
  destination -> first -> current_file = NULL;
  destination -> first -> previous = NULL;
  destination -> length = 0;

  node_file* destination_file_cursor = destination -> first;
  node_file* file_cursor = src -> first;

  while(file_cursor != NULL){
    copy_file(file_cursor -> current_file, &destination_file_cursor -> current_file);
    destination -> length ++;
    if(file_cursor -> next != NULL){
      destination_file_cursor -> next = (node_file*) malloc(sizeof(node_file));
      destination_file_cursor -> next -> previous = destination_file_cursor;
      destination_file_cursor -> next -> current_file = NULL;
      destination_file_cursor -> next -> next = NULL;
      destination_file_cursor = destination_file_cursor -> next;
    }
    file_cursor = file_cursor -> next;
  }
}

/**
DESCRIPTION:
        Create a new branch with the given name.
        Checking if branch creation is possible:
            Validity is checked in the name_valid function
            Vacancy of branch name is checked in name_occupied function.
            Changes in branch's managed file is checked in check_if_changed function.
        A new Branch should hold all the files of the currently active head branch.

RETURN VALUE: -1
        - branch_name is INVALID
        - branch_name is NULL
RETURN VALUE: -2
        - branch_name is OCCUPIED
RETURN VALUE: -3
        - Currently active head branch has uncommitted changed files.
RETURN VALUE: 0
        - If branching was done successfully
**/
int svc_branch(void *helper, char *branch_name){
  my_helper* help = (my_helper*) helper;

  //If branch_name is INVALID or NULL
  if( branch_name == NULL || name_valid(branch_name) == 1) {
    return -1;
  }

  //If branch_name is OCCUPIED
  else if(name_occupied(helper, branch_name) == 1){
    return -2;
  }

  //if currently active head branch has changed files that has not been committed yet.
  else if(check_if_changed(help -> head) == 1){
    return -3;
  }

  //Adding the newly created branch to the help -> branches linked list.
  node_branch* branch_cursor = help -> branches -> first;
  while(branch_cursor -> next != NULL){
    branch_cursor = branch_cursor -> next;
  }
  branch_cursor -> next = (node_branch*) malloc(sizeof(node_branch));
  branch_cursor -> next -> previous = branch_cursor;
  branch_cursor -> next -> current_branch = (branch*) malloc(sizeof(branch));
  branch_cursor -> next -> next = NULL;
  branch_cursor = branch_cursor -> next;


  branch_cursor -> current_branch -> branch_name = (char*) malloc(strlen(branch_name) + 1);
  strcpy(branch_cursor -> current_branch -> branch_name, branch_name);
  copy_file_list(help -> head -> managed_files, &branch_cursor -> current_branch -> managed_files );

  help -> branches -> length ++;
  return 0;
}

/**
DESCRIPTION:
        Given the branch name, make the branch with corresponding branch name the new active head branch of svc.

RETURN VALUE: -1 if
        - branch_name == NULL
        - branch name does not exist
RETURN VALUE: -2 if
        - Current active branch has changes that has not been committed
RETURN VALUE: 0 if
        - Successfully changed the current active branch (manager -> head) to the specified branch
**/
int svc_checkout(void *helper, char *branch_name){
  my_helper* help = (my_helper*) helper;

  //Check if branc_name is NULL
  if(branch_name == NULL){
    return -1;
  }

  //Traverse through the list to find a branch with corresponding branch_name
  node_branch* branch_cursor = help -> branches -> first;
  int found = 0;
  while(branch_cursor != NULL){
    if(strcmp(branch_cursor -> current_branch -> branch_name, branch_name) == 0){
      found = 1;
      break;
    }
    branch_cursor = branch_cursor-> next;
  }

  //Branch with corresponding name has not been found so we return -1
  if(found == 0){
    return -1;
  }

  // branch_cursor = the branch you wanted to change as head
  if(check_if_changed(help -> head) == 1){
    return -2;
  }

  //Change the current head branch pointer to point the branch with corresponding name.
  help -> head = branch_cursor -> current_branch;
  return 0;
}

/**
DESCRIPTION:
      Print all the branches in the order they were created, AND return a DYNAMICALLY ALLOCATED ARRAY of branch names in the same order.

Successive Unit Case:
      1. print all the branches in the order they were created
      2. allocate and return dynamically allocated array of the branch names in order
      3. store number of branches in "n_branches" varaible passed as parameter.

RETURN VALUE: NULL if
      - n_branches == NULL
RETURN VALUE: dynamically allocated array if
      - all is Successfully done!
**/
char **list_branches(void *helper, int *n_branches){
  my_helper* help = (my_helper*) helper;

  //Check if n_branches is NULL
  if(n_branches == NULL){
    return NULL;
  }

  //Initialise and Allocate list to hold the address of branch_name for each branches.
  *n_branches = help -> branches -> length;
  char** branch_name_list = (char**) malloc(sizeof(char*) * (*n_branches));

  /**
  Traverse through the branch linked list and:
      1. Print the name of branches in order.
      2. save the name of branches in the list created.
  **/
  node_branch* branch_cursor = help -> branches -> first;
  for(int i = 0; i < *n_branches; i++){
    printf("%s\n", branch_cursor -> current_branch-> branch_name);
    branch_name_list[i] = branch_cursor -> current_branch -> branch_name;
    branch_cursor = branch_cursor -> next;
  }
  return branch_name_list;
}

/**
DESCRIPTION:
        Add a file with file name "file_name" into the current active branch

Successive Unit Case:
        1. calculate the file's hashvalue;
        2. convert file into file struct and then as node_file
        3. insert node_file into the last element in managed_files with state value as 2
        4. return the hash value of the file added.

RETURN VALUE: -1 if
        - file_name == NULL

RETURN VALUE: -2 if
        - file name EXISTS in the currently active branch

RETURN VALUE: file's hash value if
        - if the file is NOT BEING TRACKED in the currently active branch
        - successfully added to the branch
**/
int svc_add(void *helper, char *file_name){
  my_helper* manager = (my_helper*) helper;

  //Check if file_name provided is NULL
  if(file_name == NULL){
    return -1;
  }



  //Check if the file_name is already added onto the managed_files of head branch.
  node_file* file_cursor = manager -> head -> managed_files -> first;


  if(file_cursor != NULL){
    int found = 0;
    while(file_cursor -> next != NULL){
      if(strcmp(file_cursor -> current_file -> file_name, file_name) == 0){
        found = 1;
        break;
      }
      file_cursor = file_cursor -> next;
    }
    if(found == 1 || strcmp(file_cursor -> current_file -> file_name, file_name) == 0){
      return -2;
    }

    //if head branch holds one or more files in it's file linked list.
    else{
      file_cursor -> next = (node_file*) malloc(sizeof(node_file));
      file_cursor -> next -> previous = file_cursor;
      file_cursor -> next -> current_file = NULL;
      file_cursor -> next -> next = NULL;
      file_cursor = file_cursor -> next;
    }
  }
  else{
    manager -> head -> managed_files -> first = (node_file*) malloc(sizeof(node_file));
    manager -> head -> managed_files -> first -> previous = NULL;
    manager -> head -> managed_files -> first -> current_file = NULL;
    manager -> head -> managed_files -> first -> next = NULL;
    file_cursor = manager -> head -> managed_files -> first;
  }


  //calculate the hash value;
  int hashvalue = hash_file(helper, file_name);

  //If hash_value is -2, it means that file_path provided does not exist
  if(hashvalue == -2){
    return -3;
  }

  //Create and allocate space for file struct to store the newly added file to the managed_files linked list.
  file_cursor -> current_file = (file*) malloc(sizeof(file));
  file_cursor -> current_file -> file_name = (char*) malloc(strlen(file_name) + 1);
  strcpy(file_cursor -> current_file -> file_name, file_name);
  file_cursor -> current_file -> file_hash = hashvalue;
  file_cursor -> current_file -> state = 2;


  manager -> head -> managed_files -> length ++;

  //return hash value of the file added
  return hashvalue;
}

/**
DESCRIPTION:
        Convert a file -> state of a file with file name "file_name" to 3 so that it can be removed at next commit.

Successive Unit Case:
        1. Check if the file_name is a valid name
        2. Traverse through the linked list of my_helper -> head -> managed_files and find the file with corresponding file_name.
        3. Convert that file's file-> state to 3.
RETURN VALUE: -1 if
        - file_name == NULL

RETURN VALUE: -2 if
        - file name DOES NOT exists in the currently active branch

RETURN VALUE: file's hash value if
        - if the file is in the currently active branch
        - successfully changed its file-> state to 3.
**/
int svc_rm(void *helper, char *file_name){
  my_helper* manager = (my_helper*) helper;

  //Check to see if file_name is NULL
  if(file_name == NULL){
    return -1;
  }

  node_file* file_cursor = manager -> head -> managed_files -> first;
  while(file_cursor != NULL){
    if(strcmp(file_cursor -> current_file -> file_name, file_name) == 0){
      break;
    }
    file_cursor= file_cursor -> next;
  }

  //Check if found is 0, if so was no file with corresponding name of file_name
  if(file_cursor == NULL || file_cursor -> current_file -> state == 3){
    return -2;
  }

  file_cursor -> current_file -> state = 3;

  return file_cursor -> current_file -> file_hash;
}
