typedef struct branch branch;
typedef struct commit commit;
typedef struct file file;

typedef struct node_branch node_branch;
typedef struct node_commit node_commit;
typedef struct node_file node_file;

typedef struct linked_list_branch linked_list_branch;
typedef struct linked_list_commit linked_list_commit;
typedef struct linked_list_file linked_list_file;

typedef struct my_helper my_helper;

typedef struct linked_list_text linked_list_text;
typedef struct node_text node_text;

struct linked_list_text{
  node_text* first;
  int length;
};

struct node_text{
  char* current_text;
  int state;
  node_text* next;
  node_text* previous;
};

struct my_helper{
  linked_list_branch* branches;
  linked_list_commit* commits;
  branch* head;
};


struct linked_list_branch{
  struct node_branch* first;
  int length;
};

struct node_branch{
  struct branch* current_branch;
  struct node_branch* next;
  struct node_branch* previous;
};

struct linked_list_commit{
  struct node_commit* first;
  int length;
};

struct node_commit{
  struct commit* current_commit;
  struct node_commit* next;
  struct node_commit* previous;
};


struct linked_list_file{
  struct node_file* first;
  int length;
};

struct node_file{
  struct file* current_file;
  struct node_file* next;
  struct node_file* previous;
};

struct file{
  char* file_name;
  int file_hash;

  /**
  0 = tracked
  1 = changed
  2 = added
  3 = removed
  **/
  int state;
};

struct branch{
  char* branch_name;
  linked_list_file* managed_files;
};

struct commit{
  char* commit_id;
  char* commit_message;
  char* branch_name;
  linked_list_file* managed_files;
};
